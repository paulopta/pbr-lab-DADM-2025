import FlatListBasico from './components/FlatListBasico'
import FlatListCustomizado from './components/FlatListCustomizado'
import FlatListOtimizado from './components/FlatListOtimizado'
import FlatListAPI from './components/FlatListAPI'


export default function App() {
  return (
      <FlatListBasico/>
  );
}

{/*   
      <FlatListBasico/>
      <FlatListCustomizado/>
      <FlatListOtimizado/>
      <FlatListAPI/>
*/}
