import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, Image, TouchableOpacity, RefreshControl } from 'react-native';

const FlatListAPI = () => {
  const [dados, setDados] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [pagina, setPagina] = useState(1);
  const [carregandoMais, setCarregandoMais] = useState(false);

  // Função para buscar dados da API
  const buscarDados = async (pag = 1, refresh = false) => {
    try {
      if (refresh) {
        setRefreshing(true);
      } else if (pag === 1) {
        setCarregando(true);
      } else {
        setCarregandoMais(true);
      }

      // Usando a API JSONPlaceholder para exemplo
      const resposta = await fetch(
        `https://jsonplaceholder.typicode.com/photos?_page=${pag}&_limit=10`
      );
      
      if (!resposta.ok) {
        throw new Error('Falha ao buscar dados da API');
      }
      
      const novosItens = await resposta.json();
      
      if (refresh || pag === 1) {
        setDados(novosItens);
        setPagina(1);
      } else {
        setDados(dadosAnteriores => [...dadosAnteriores, ...novosItens]);
      }
      
      setErro(null);
    } catch (error) {
      setErro(error.message);
      console.error('Erro ao buscar dados:', error);
    } finally {
      setCarregando(false);
      setRefreshing(false);
      setCarregandoMais(false);
    }
  };

  // Carregar dados iniciais
  useEffect(() => {
    buscarDados();
  }, []);

  // Função para atualizar a lista (pull-to-refresh)
  const onRefresh = () => {
    buscarDados(1, true);
  };

  // Função para carregar mais itens ao chegar ao final da lista
  const carregarMaisItens = () => {
    if (!carregandoMais && !refreshing) {
      buscarDados(pagina + 1);
      setPagina(pagina + 1);
    }
  };

  // Componente para renderizar cada item
  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.item}
      onPress={() => console.log(`Item ${item.id} clicado`)}
    >
      <Image 
        source={{ uri: item.thumbnailUrl }} 
        style={styles.imagem}
      />
      <View style={styles.conteudo}>
        <Text style={styles.titulo} numberOfLines={1}>
          {item.title}
        </Text>
        <Text style={styles.subtitulo}>ID: {item.id}</Text>
      </View>
    </TouchableOpacity>
  );

  // Componente para o rodapé da lista (indicador de carregamento)
  const ListFooter = () => {
    if (!carregandoMais) return null;
    
    return (
      <View style={styles.footerLoader}>
        <ActivityIndicator size="small" color="#3498db" />
        <Text style={styles.footerText}>Carregando mais itens...</Text>
      </View>
    );
  };

  // Componente para quando a lista estiver vazia
  const ListEmpty = () => {
    if (carregando) {
      return (
        <View style={styles.emptyContainer}>
          <ActivityIndicator size="large" color="#3498db" />
          <Text style={styles.emptyText}>Carregando dados...</Text>
        </View>
      );
    }
    
    if (erro) {
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.errorText}>Erro: {erro}</Text>
          <TouchableOpacity 
            style={styles.retryButton}
            onPress={() => buscarDados()}
          >
            <Text style={styles.retryButtonText}>Tentar novamente</Text>
          </TouchableOpacity>
        </View>
      );
    }
    
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>Nenhum item encontrado</Text>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={dados}
        renderItem={renderItem}
        keyExtractor={item => item.id.toString()}
        ListEmptyComponent={ListEmpty}
        ListFooterComponent={ListFooter}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#3498db']}
          />
        }
        onEndReached={carregarMaisItens}
        onEndReachedThreshold={0.1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  item: {
    backgroundColor: '#fff',
    padding: 15,
    marginVertical: 8,
    marginHorizontal: 16,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  imagem: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  conteudo: {
    flex: 1,
    marginLeft: 15,
  },
  titulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  subtitulo: {
    fontSize: 14,
    color: '#666',
    marginTop: 3,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    height: 300,
  },
  emptyText: {
    fontSize: 18,
    color: '#999',
    marginTop: 10,
  },
  errorText: {
    fontSize: 18,
    color: '#e74c3c',
    marginTop: 10,
    textAlign: 'center',
  },
  retryButton: {
    marginTop: 15,
    padding: 10,
    backgroundColor: '#3498db',
    borderRadius: 5,
  },
  retryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  footerLoader: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
  },
  footerText: {
    marginLeft: 10,
    fontSize: 16,
    color: '#666',
  },
});

export default FlatListAPI;
