import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';

const FlatListCustomizado = () => {
  // Estado para controlar o refresh
  const [refreshing, setRefreshing] = useState(false);
  
  // Dados para a lista
  const dados = [
    { id: '1', titulo: 'Item 1', descricao: 'Descrição do item 1' },
    { id: '2', titulo: 'Item 2', descricao: 'Descrição do item 2' },
    { id: '3', titulo: 'Item 3', descricao: 'Descrição do item 3' },
    { id: '4', titulo: 'Item 4', descricao: 'Descrição do item 4' },
    { id: '5', titulo: 'Item 5', descricao: 'Descrição do item 5' },
    { id: '6', titulo: 'Item 6', descricao: 'Descrição do item 6' },
    { id: '7', titulo: 'Item 7', descricao: 'Descrição do item 7' },
    { id: '8', titulo: 'Item 8', descricao: 'Descrição do item 8' },
    { id: '9', titulo: 'Item 9', descricao: 'Descrição do item 9' },
    { id: '10', titulo: 'Item 10', descricao: 'Descrição do item 10' },
  ];

  // Componente para renderizar cada item
  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.item}
      onPress={() => console.log(`Item ${item.id} clicado`)}
    >
      <Text style={styles.titulo}>{item.titulo}</Text>
      <Text style={styles.descricao}>{item.descricao}</Text>
    </TouchableOpacity>
  );

  // Componente para o cabeçalho da lista
  const ListHeader = () => (
    <View style={styles.header}>
      <Text style={styles.headerText}>Lista de Itens</Text>
      <Text style={styles.subHeaderText}>Toque em um item para selecioná-lo</Text>
    </View>
  );

  // Componente para o rodapé da lista
  const ListFooter = () => (
    <View style={styles.footer}>
      <Text style={styles.footerText}>Total de itens: {dados.length}</Text>
    </View>
  );

  // Componente para o separador entre itens
  const ItemSeparator = () => <View style={styles.separator} />;

  // Componente para quando a lista estiver vazia
  const ListEmpty = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyText}>Nenhum item encontrado</Text>
    </View>
  );

  // Função para simular um refresh
  const handleRefresh = () => {
    setRefreshing(true);
    // Simulando uma operação assíncrona
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  };

  // Função para carregar mais itens quando chegar ao final da lista
  const handleEndReached = () => {
    console.log('Chegou ao final da lista, carregando mais itens...');
    // Aqui você implementaria a lógica para carregar mais itens
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={dados}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        ListHeaderComponent={ListHeader}
        ListFooterComponent={ListFooter}
        ItemSeparatorComponent={ItemSeparator}
        ListEmptyComponent={ListEmpty}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        onEndReached={handleEndReached}
        onEndReachedThreshold={0.1}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  item: {
    backgroundColor: '#fff',
    padding: 20,
    marginHorizontal: 16,
  },
  titulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  descricao: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
  },
  header: {
    padding: 20,
    backgroundColor: '#3498db',
    alignItems: 'center',
  },
  headerText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
  },
  subHeaderText: {
    fontSize: 14,
    color: '#fff',
    marginTop: 5,
  },
  footer: {
    padding: 20,
    backgroundColor: '#f1f1f1',
    alignItems: 'center',
  },
  footerText: {
    fontSize: 16,
    color: '#666',
  },
  separator: {
    height: 1,
    backgroundColor: '#e1e1e1',
    marginLeft: 16,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 18,
    color: '#999',
  },
});

export default FlatListCustomizado;
