import React from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';

const FlatListBasico = () => {
  // Dados para a lista
  const dados = [
    { id: '1', titulo: 'Item 1', descricao: 'Descrição do item 1' },
    { id: '2', titulo: 'Item 2', descricao: 'Descrição do item 2' },
    { id: '3', titulo: 'Item 3', descricao: 'Descrição do item 3' },
    { id: '4', titulo: 'Item 4', descricao: 'Descrição do item 4' },
    { id: '5', titulo: 'Item 5', descricao: 'Descrição do item 5' },
    { id: '6', titulo: 'Item 6', descricao: 'Descrição do item 6' },
    { id: '7', titulo: 'Item 7', descricao: 'Descrição do item 7' },
    { id: '8', titulo: 'Item 8', descricao: 'Descrição do item 8' },
    { id: '9', titulo: 'Item 9', descricao: 'Descrição do item 9' },
    { id: '10', titulo: 'Item 10', descricao: 'Descrição do item 10' },
  ];

  // Componente para renderizar cada item
  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text style={styles.titulo}>{item.titulo}</Text>
      <Text style={styles.descricao}>{item.descricao}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={dados}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingTop: 20,
  },
  item: {
    backgroundColor: '#fff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  titulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  descricao: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
  },
});

export default FlatListBasico;
