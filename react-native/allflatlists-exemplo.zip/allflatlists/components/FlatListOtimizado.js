import React, { useState, useCallback, memo } from 'react';
import { View, Text, StyleSheet, FlatList, Image } from 'react-native';

// Componente de item otimizado com memo para evitar re-renderizações desnecessárias
const Item = memo(({ titulo, descricao, imagem }) => {
  console.log(`Renderizando item: ${titulo}`);
  return (
    <View style={styles.item}>
      <Image 
        source={{ uri: imagem }} 
        style={styles.imagem}
        // Propriedades para otimizar o carregamento de imagens
        resizeMode="cover"
        fadeDuration={300}
      />
      <View style={styles.conteudo}>
        <Text style={styles.titulo}>{titulo}</Text>
        <Text style={styles.descricao}>{descricao}</Text>
      </View>
    </View>
  );
});

const FlatListOtimizado = () => {
  // Dados para a lista (simulando uma lista grande)
  const [dados, setDados] = useState(
    Array(100).fill().map((_, index) => ({
      id: `${index + 1}`,
      titulo: `Item ${index + 1}`,
      descricao: `Descrição do item ${index + 1}`,
      imagem: `https://picsum.photos/id/${(index % 50) + 1}/200/200`,
    }))
  );

  // Função de renderização otimizada com useCallback
  const renderItem = useCallback(({ item }) => (
    <Item 
      titulo={item.titulo} 
      descricao={item.descricao} 
      imagem={item.imagem}
    />
  ), []);

  // Função para extrair as chaves otimizada com useCallback
  const keyExtractor = useCallback((item) => item.id, []);

  // Função para calcular o layout dos itens para melhorar a performance de rolagem
  const getItemLayout = useCallback(
    (data, index) => ({
      length: 90, // Altura de cada item + margem
      offset: 90 * index,
      index,
    }),
    []
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={dados}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        
        // Propriedades para otimização de performance
        getItemLayout={getItemLayout}
        removeClippedSubviews={true}
        maxToRenderPerBatch={10}
        updateCellsBatchingPeriod={50}
        windowSize={21}
        initialNumToRender={10}
        
        // Configuração visual
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  listContent: {
    paddingVertical: 10,
  },
  item: {
    backgroundColor: '#fff',
    padding: 10,
    marginVertical: 5,
    marginHorizontal: 16,
    borderRadius: 5,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    height: 80,
  },
  imagem: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 10,
  },
  conteudo: {
    flex: 1,
  },
  titulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  descricao: {
    fontSize: 14,
    color: '#666',
    marginTop: 3,
  },
});

export default FlatListOtimizado;
