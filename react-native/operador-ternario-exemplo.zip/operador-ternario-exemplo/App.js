import { useCallback, useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import Entypo from '@expo/vector-icons/Entypo';


export default function App() {

const isLoggedIn = true;
const mensagem = isLoggedIn ? "Bem-vindo!" : "Faça login";

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>{mensagem} 👋</Text>
      <Entypo name="rocket" size={30} />
    </View>
  );
}
