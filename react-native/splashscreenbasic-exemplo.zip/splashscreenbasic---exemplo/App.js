import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

// Tela Splash (só a logo)
function SplashScreen() {
  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://www.pucminas.br/institucional/PublishingImages/Paginas/brasao/brasao-pucminas-versao-2025.png' }}
        style={styles.logo}
      />
    </View>
  );
}

// Tela principal (Home)
function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Bem-vindo ao meu App 🎉</Text>
    </View>
  );
}

// Componente principal do App
export default function App() {
  const [mostrarSplash, setMostrarSplash] = useState(true);

  useEffect(() => {
    // Mostra a splash por 2 segundos
    const timer = setTimeout(() => {
      setMostrarSplash(false);
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  if (mostrarSplash) {
    return <SplashScreen />;
  }

  return <HomeScreen />;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  logo: {
    width: 150,
    height: 150,
    resizeMode: 'contain',
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
});
