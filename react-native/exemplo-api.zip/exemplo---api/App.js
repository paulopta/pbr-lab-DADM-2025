import {useState} from 'react'
import { Appbar } from 'react-native-paper';
import {View, Text, StyleSheet} from 'react-native'
import { Button, TextInput } from 'react-native-paper';

const App = () => {

  const [logradouro,setLogradouro] = useState("");
  const [bairro, setBairro] = useState("");
  const [cidade,setCidade] = useState("");
  const [estado,setEstado] = useState("");
  const [cep,setCep] = useState("");

  
  function buscaEnd(){


fetch('https://viacep.com.br/ws/'+cep+'/json/')
      .then(response => response.json()) // Parse the response as JSON
      .then(data => 
        {
          setLogradouro(data.logradouro);
          setBairro(data.bairro);
          setCidade(data.localidade);
          setEstado(data.uf);
          setCep(data.cep);
        }
      )
      .catch(error => console.error('Error:', error));
     
  }


  return(
    <>
    <Appbar.Header theme={{ colors: { primary: 'green' } }}>
      <Appbar.Content title="Descobre Endereço" />
      <Appbar.Action icon="magnify"  />
    </Appbar.Header>

    <View style={styles.content}>     
        <TextInput
          onChangeText={(text)=>setCep(text)}
          value={cep}
          placeholder="cep"
          keyboardType="numeric"
        />
        <Button 
          icon="magnify" 
          mode="contained" 
          color= "green"
          onPress={() => buscaEnd()}
        >
          Descobrir
        </Button>
        <Text style={styles.titulo}>Logradouro: </Text>
        <Text>{logradouro}</Text>
        <Text style={styles.titulo}>Bairro:</Text>
        <Text>{bairro}</Text>
        <Text style={styles.titulo}>Cidade:</Text>
        <Text>{cidade}</Text>
        <Text style={styles.titulo}>Estado:</Text>
        <Text>{estado}</Text>
        <Text style={styles.titulo}>CEP:</Text>
        <Text>{cep}</Text>
        
    </View>
    </>
  );

}

const styles = StyleSheet.create({
  content:{
    flex:1,
    justifyContent: 'center',    
    alignItems:'center',
    gap: 10
  },
  titulo:{
    fontWeight: "bold"
  }
});

export default App;