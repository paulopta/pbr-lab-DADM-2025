import StackNavigator from './src/navigations/StackNavigation'
import TopTabNavigator from './src/navigations/TobTabNavigation'
import BottomNavigator from './src/navigations/BottomNavigation'
import DrawerNavigator from './src/navigations/DrawerNavigation'

export default function App(){
  return(
    <TopTabNavigator />
  );
}

{/*<StackNavigator />*/}
{/*<TopTabNavigator />*/}
{/*<BottomNavigator />*/}
{/*<DrawerNavigator />*/}