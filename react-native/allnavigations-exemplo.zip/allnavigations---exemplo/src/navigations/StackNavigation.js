import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// importando as telas externas
import ScreenA from '../screens/ScreenA';
import ScreenB from '../screens/ScreenB';
import ScreenC from '../screens/ScreenC';
import ScreenD from '../screens/ScreenD';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Screen A" component={ScreenA} />
        <Stack.Screen name="Screen B" component={ScreenB} />
        <Stack.Screen name="Screen C" component={ScreenC} />
        <Stack.Screen name="Screen D" component={ScreenD} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
