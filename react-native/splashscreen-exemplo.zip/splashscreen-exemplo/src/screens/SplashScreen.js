import React, { useEffect, useRef } from 'react';
import { ImageBackground, StyleSheet, View, Animated } from 'react-native';

const Splash = ({ navigation  }) => {
  const spinValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.timing(spinValue, {
        toValue: 1,
        duration: 1500,
        useNativeDriver: true,
      },[])
    ).start();

    setTimeout(() => {
      navigation.navigate('Home');
    }, 3000);
  });

  const spin = spinValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

 {/* Exemplo sem rotação -  ou retire o atributos style ds tag Animated 
 useEffect(() => {
    setTimeout(() => {
      navigation.navigate('Home');
    }, 3000);
  }, []);*/}


  return (
    <ImageBackground
    source={require("../img/background_bg.png")}
    style={styles.background}
  >
    <View style={styles.container}> {/**/}
      <Animated.Image source={require('../img/mortal_kombat_logo.png')} style={{ transform: [{ rotate: spin }] }}/>
    </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  background: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
  }
});

export default Splash;