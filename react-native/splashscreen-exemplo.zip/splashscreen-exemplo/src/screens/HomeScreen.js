import { View, Text, Button } from "react-native";

export default function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text style={{ fontSize: 20 }}>🏠 Página Inicial</Text>
      <Button
        title="Ir para Detalhes"
        onPress={() => navigation.navigate("Details", { nome: "Paulo" })}
      />
    </View>
  );
}