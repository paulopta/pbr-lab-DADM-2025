import { View, Text, Button } from "react-native";

export default function DetailsScreen({ route, navigation }) {
  const { nome } = route.params || {};

  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text style={{ fontSize: 20 }}>📄 Tela de Detalhes</Text>
      {nome && <Text>Bem-vindo, {nome}!</Text>}
      <Button title="Voltar" onPress={() => navigation.goBack()} />
    </View>
  );
}