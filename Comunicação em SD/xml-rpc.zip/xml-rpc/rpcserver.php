<?php
// Cria os métodos remotos

// Método remoto para somar dois números
function somar($method_name, $args) {
    return $args[0] + $args[1];
}

// Método remoto para concatenar duas strings 
function concatenar($method_name, $args) {
    return $args[0] . $args[1];
}

// Método remoto para ordenar um array com nome e código 
function ordenar($method_name, $args) {
	ksort($args[0]);
	asort($args[1]);
    return $args;
}

// Cria o servidor XMLRPC
$xmlrpc_server = xmlrpc_server_create();

// Registra os métodos no servidor XMLRPC
xmlrpc_server_register_method($xmlrpc_server, "somar", "somar");
xmlrpc_server_register_method($xmlrpc_server, "concatenar", "concatenar");
xmlrpc_server_register_method($xmlrpc_server, "ordenar", "ordenar");

// Recupera o XML com a requisição do Cliente
$request_xml = file_get_contents("php://input");

// Salva em um arquivo o XML enviado pelo cliente =D
file_put_contents('client_request.txt', file_get_contents('php://input'));

// Recebe e processa a requisição do Cliente
header('Content-Type: text/xml');
print xmlrpc_server_call_method($xmlrpc_server, $request_xml, array());
?>