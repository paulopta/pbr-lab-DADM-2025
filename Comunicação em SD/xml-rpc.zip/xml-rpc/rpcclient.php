<html>
<head>
<title>RPC - Client Request</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<?php
// Preenche os valores de parâmetros para os procedimentos remotos
$params_soma = array(1,3);
$params_concatenacao = array('James ','Bond');
$params_ordenacao = array(array('key_3'=>'Banana', 'key_1'=>'Maça', 'key_2'=>'Uva'), array('Ana'=>'Criança', 'Maria'=>'Aduto', 'Pedro'=>'Jovem'));
 
// Empacotamento do método e dos parâmetros para acionar o procedimento remoto
$request1 = xmlrpc_encode_request("somar", $params_soma,array('encoding'=>'UTF-8','escaping'=>'markup'));
$request2 = xmlrpc_encode_request("concatenar", $params_concatenacao,array('encoding'=>'UTF-8','escaping'=>'markup'));
$request3 = xmlrpc_encode_request("ordenar", $params_ordenacao,array('encoding'=>'UTF-8','escaping'=>'markup'));

$request = $request1;

// Cria o stream de requisição
$context = stream_context_create(array('http' => array(
    'method' => "POST",
    'header' => "Content-Type: text/xml\r\nUser-Agent: PHPRPC/1.0\r\n",
    'content' => $request
)));

// Exibe o arquivo de Requisição na página
echo "Requisição feita pelo Cliente: <br/>";
var_dump($request);

//Ligação direta com o servidor XMLRPC via URL
$server = 'http://localhost/xmlrpc/rpcserver.php';

// Executa a Requisição
$file = file_get_contents($server, false, $context);
echo "Resposta feita pelo Servidor: <br/>";
var_dump($file);
//Decoddificação da Respota
$response = xmlrpc_decode($file,'UTF-8');

// Exibe o arquivo de Resposta na página
echo "Decodificação da Resposta <br/>";
var_dump($response);
?>
<body>
<html>