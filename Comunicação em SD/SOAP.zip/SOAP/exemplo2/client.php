<?php
try {
    // Criar cliente SOAP sem WSDL
    $client = new SoapClient(null, [
        'location' => 'http://localhost/soap_exemplos/exemplo2Git/server.php',
        'uri'      => 'http://localhost/soap_exemplos/exemplo2Git/server.php',
        'trace'    => 1
    ]);

    echo "5 + 3 = " . $client->soma(5, 3) . "\n";
    echo "10 - 4 = " . $client->subtracao(10, 4) . "\n";
    echo "6 * 7 = " . $client->multiplicacao(6, 7) . "\n";
    echo "20 / 5 = " . $client->divisao(20, 5) . "\n";

} catch (SoapFault $e) {
    echo "Erro: " . $e->getMessage();
}

?>