<?php
// Ativar exibição de erros para debug
ini_set("soap.wsdl_cache_enabled", "0");
ini_set("display_errors", 1);
error_reporting(E_ALL);


// Classe com métodos que serão expostos via SOAP
class Calculadora {
    public function soma($a, $b) {
        return $a + $b;
    }

    public function subtracao($a, $b) {
        return $a - $b;
    }

    public function multiplicacao($a, $b) {
        return $a * $b;
    }

    public function divisao($a, $b) {
        if ($b == 0) {
            throw new SoapFault("Server", "Divisão por zero não permitida!");
        }
        return $a / $b;
    }
}

 // O WSDL pode ser gerado a partir da URL do seu servidor SOAP.
    $uri = 'http://localhost/soap_exemplos/exemplo2/server.php'; // URL para o seu arquivo do SoapServer

// Define as opções de WSDL para que sejam geradas automaticamente
    $options = [
        'uri' => $uri,
        'style' => SOAP_RPC, // Outros estilos podem ser SOAP_DOCUMENT
        'use' => SOAP_ENCODED // Ou SOAP_LITERAL
    ];

// Criando servidor SOAP sem WSDL
$server = new SoapServer(null, $options);
$server->setClass("Calculadora");
$server->handle();

?>