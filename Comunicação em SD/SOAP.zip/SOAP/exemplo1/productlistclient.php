<?php

require_once "nusoap.php";

$client = new nusoap_client("http://localhost/soap_exemplos/exemplo1/productlist.php");
//$client = new SoapClient("products.wsdl", array('soap_version' => SOAP_1_1));
$client->soap_defencoding = 'UTF-8';
$error = $client->getError();


if ($error) {


    echo "<h2>Constructor error</h2><pre>" . $error . "</pre>";


}


$result = $client->call("getProd", array("category" => "books"));
$result2 = $client->call("otherFunction", array("category books"));

if ($client->fault) {


    echo "<h2>Fault</h2><pre>";


    print_r($result);


    echo "</pre>";


}


else {


    $error = $client->getError();


    if ($error) {


        echo "<h2>Error</h2><pre>" . $error . "</pre>";


    }


    else {


        echo "<h2>Books</h2><pre>";


        echo $result;


        echo "</pre>";

        echo "<h2>Phrase</h2><pre>";


        echo $result2;


        echo "</pre>";


    }

    echo "<h2>Request</h2>";

    echo "<pre>" . htmlspecialchars($client->request, ENT_QUOTES) . "</pre>";

    echo "<h2>Response</h2>";

    echo "<pre>" . htmlspecialchars($client->response, ENT_QUOTES) . "</pre>";

}
?>